import React from 'react';

function App(){
    return(
    <>
    <button>-</button>
    <span>0</span>
    <button>+</button>
    </>
    )
}

